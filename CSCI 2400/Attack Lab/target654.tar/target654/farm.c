/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_293(unsigned x)
{
    return x + 239584088U;
}

void setval_224(unsigned *p)
{
    *p = 3347663043U;
}

unsigned getval_332()
{
    return 3273137797U;
}

unsigned addval_388(unsigned x)
{
    return x + 2428995912U;
}

unsigned addval_369(unsigned x)
{
    return x + 1490321032U;
}

void setval_103(unsigned *p)
{
    *p = 2462550344U;
}

unsigned getval_266()
{
    return 2425393496U;
}

unsigned getval_378()
{
    return 3347695775U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_261(unsigned *p)
{
    *p = 2447411528U;
}

void setval_282(unsigned *p)
{
    *p = 3224949133U;
}

void setval_341(unsigned *p)
{
    *p = 2425474697U;
}

void setval_234(unsigned *p)
{
    *p = 3285289341U;
}

unsigned addval_215(unsigned x)
{
    return x + 2425409945U;
}

unsigned getval_437()
{
    return 2425409165U;
}

unsigned addval_491(unsigned x)
{
    return x + 3767093280U;
}

void setval_182(unsigned *p)
{
    *p = 3372798217U;
}

unsigned getval_123()
{
    return 2425541001U;
}

unsigned addval_189(unsigned x)
{
    return x + 3229926025U;
}

void setval_294(unsigned *p)
{
    *p = 2430642504U;
}

unsigned getval_151()
{
    return 3223376264U;
}

void setval_235(unsigned *p)
{
    *p = 2464188744U;
}

unsigned getval_399()
{
    return 3281047177U;
}

unsigned getval_164()
{
    return 2430634312U;
}

unsigned getval_196()
{
    return 3526935177U;
}

void setval_125(unsigned *p)
{
    *p = 3678981769U;
}

unsigned addval_474(unsigned x)
{
    return x + 2447411528U;
}

unsigned addval_423(unsigned x)
{
    return x + 3687108233U;
}

unsigned getval_109()
{
    return 3281043977U;
}

unsigned getval_447()
{
    return 2464188744U;
}

unsigned addval_237(unsigned x)
{
    return x + 3372798345U;
}

void setval_446(unsigned *p)
{
    *p = 3525366185U;
}

void setval_162(unsigned *p)
{
    *p = 3264077006U;
}

unsigned getval_284()
{
    return 3871851145U;
}

unsigned addval_226(unsigned x)
{
    return x + 3674784457U;
}

unsigned addval_192(unsigned x)
{
    return x + 3269495112U;
}

void setval_467(unsigned *p)
{
    *p = 3281047049U;
}

void setval_489(unsigned *p)
{
    *p = 3281044169U;
}

unsigned getval_300()
{
    return 3674787465U;
}

unsigned addval_262(unsigned x)
{
    return x + 3523268233U;
}

unsigned addval_319(unsigned x)
{
    return x + 3223896713U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
