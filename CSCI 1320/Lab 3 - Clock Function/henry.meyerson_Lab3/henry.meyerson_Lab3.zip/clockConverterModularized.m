%Henry Meyerson
%CSCI 1320 - 235
%109190761
%Lab 3 - Clock Function - MODULARIZED!

%Input Function (getInputs)
[h,m,s,f,t] = getInputs();
%Conversion Function (convertTime)
[h,m,s,f,t] = convertTime(h,m,s,f,t);
%Display Function (displayTime)
displayTime(h,m,s,f,t);