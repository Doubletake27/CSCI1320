%Henry Meyerson
%Sound Echo Function

function echoVec = soundEcho(soundVec,Fs,delay,echoGain);
    %Converts number of seconds into a index size
    delaySamples = Fs*delay;
    %Creates a vector of zeros of the length of delayed samples
    %adds said vector to the begining of sound vec and stores as new vector
    %multiplies new vector by the gain
    %adds the two vectors together
    %plays new sound
end