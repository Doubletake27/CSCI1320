%Henry Meyerson
%Fast Fourier Transform Function

function [] = fftBar(soundVec,Fs)
% b. Only use at the first 1000 samples of the audio vector.
% c. Use the fast fourier transform function in MATLAB (fft) to convert the audio
% signal into the frequency domain.
% Y = fft(audioVec);
% d. The fft function will return the input signal transformed into the frequency
% domain. You will see that the vector elements will contain both real and
% imaginary components. For the purpose of this function, we will go ahead
% and ignore the imaginary component of the signal. This can be done by taking
% the absolute value of the entire vector .
% Y = abs(Y);
% e. The fft function returns both positive and negative frequencies (referred to
% as a 2-sided plot). We only want to display the positive ones. In order to do
% so, create a new vector that only contains the first half of the original vec (Y).
% f. Create a frequency vector. We will need this for our bar graph. Use the
% following expression:
% f = Fs*(0:(length(Y)-1)/2)/length(Y);
% g. Create a bar graph with frequencies on the horizontal axis and amplitudes on
% the vertical axis. Format your horizontal axis to show frequencies from 0 to 5
% kHz. You vertical axis should be scaled such that the maximum Y value takes
% up most of the bar graph.
% h. The function does not need to return anything.
end
