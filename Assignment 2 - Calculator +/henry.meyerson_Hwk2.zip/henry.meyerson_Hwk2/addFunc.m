function sum = addFunc(a, b)
sum = a + b;
end