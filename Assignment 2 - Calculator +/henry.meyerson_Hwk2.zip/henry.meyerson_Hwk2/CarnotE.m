function n = CarnotE(TC,TH)
n = 1-(TC/TH);
end