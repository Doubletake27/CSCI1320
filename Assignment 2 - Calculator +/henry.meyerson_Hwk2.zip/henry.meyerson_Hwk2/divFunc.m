function quotient = divFunc(a, b)
quotient = a / b;
end