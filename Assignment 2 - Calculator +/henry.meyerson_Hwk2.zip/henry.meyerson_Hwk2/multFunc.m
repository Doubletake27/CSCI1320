function product = multFunc(a, b)
product = a * b;
end