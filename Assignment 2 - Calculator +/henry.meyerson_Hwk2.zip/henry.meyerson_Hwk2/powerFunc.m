function expo = powerFunc(a, b)
expo = a ^ b;
end