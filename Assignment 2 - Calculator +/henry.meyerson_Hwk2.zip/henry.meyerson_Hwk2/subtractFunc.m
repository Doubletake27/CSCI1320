function difference = subtractFunc(a, b)
difference = a - b;
end